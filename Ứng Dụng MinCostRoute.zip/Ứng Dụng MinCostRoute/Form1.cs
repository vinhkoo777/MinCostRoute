﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static MinCostRoute.Form1;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace MinCostRoute
{
    public partial class Form1 : Form
    {
        private Graph graph;
        private DoubleLinkedList shortestPath;
        private Car selectedCar;
        public double Weight { get;set; }
        public Form1()
        {
            InitializeComponent();
            graph = new Graph();

        }
        private void Form1_Load(object sender, EventArgs e)
        {
            graph.AddLocation("TP.HCM", "HCM", 495, 239);
            graph.AddLocation("Long An", "LA", 424, 251);
            graph.AddLocation("Tiền Giang", "TG", 416, 285);
            graph.AddLocation("Bến Tre", "BT", 464, 324);
            graph.AddLocation("Vĩnh Long", "VL", 391, 331);
            graph.AddLocation("Trà Vinh", "TV", 446, 370);
            graph.AddLocation("Đồng Tháp", "DT", 337, 263);
            graph.AddLocation("An Giang", "AG", 279, 284);
            graph.AddLocation("Cần Thơ", "CT", 329, 330);
            graph.AddLocation("Hậu Giang", "HG", 340, 374);
            graph.AddLocation("Sóc Trăng", "ST", 386, 406);
            graph.AddLocation("Kiên Giang", "KG", 276, 365);
            graph.AddLocation("Bạc Liêu", "BL", 323, 440);
            graph.AddLocation("Cà Mau", "CM", 248, 483);
            graph.AddLocation("Bình Phước", "BP", 532, 109);
            graph.AddLocation("Bình Dương", "BD", 479, 178);
            graph.AddLocation("Đồng Nai", "DN", 572, 209);
            graph.AddLocation("Bà Rịa - Vũng Tàu", "BRVT", 578, 267);
            graph.AddLocation("Tây Ninh", "TN", 414, 145);
            LinkedList locations = graph.GetLocations();
            Node current = locations.header.link; 

            while (current != null)
            {
                comboBox1.Items.Add(current.element);
                comboBox2.Items.Add(current.element);
                current = current.link;
            }
            graph.AddConnection("TP.HCM", "Bình Dương", 28.8);
            graph.AddConnection("TP.HCM", "Đồng Nai", 33.7);
            graph.AddConnection("TP.HCM", "Tây Ninh", 97.1);
            graph.AddConnection("TP.HCM", "Long An", 46.2);
            graph.AddConnection("TP.HCM", "Bà Rịa - Vũng Tàu", 78.8);
            graph.AddConnection("Bình Dương", "Bình Phước", 72.4);
            graph.AddConnection("Bình Dương", "Tây Ninh", 83);
            graph.AddConnection("Bình Dương", "Đồng Nai", 24.4);
            graph.AddConnection("Bình Phước", "Tây Ninh", 108);
            graph.AddConnection("Bình Phước", "Đồng Nai", 84);
            graph.AddConnection("Đồng Nai", "Bà Rịa - Vũng Tàu", 71.5);
            graph.AddConnection("Long An", "Tiền Giang", 22.9);
            graph.AddConnection("Long An", "Đồng Tháp", 100);
            graph.AddConnection("Tiền Giang", "Bến Tre", 17);
            graph.AddConnection("Tiền Giang", "Vĩnh Long", 71.5);
            graph.AddConnection("Tiền Giang", "Đồng Tháp", 94.1);
            graph.AddConnection("Bến Tre", "Trà Vinh", 44);
            graph.AddConnection("Bến Tre", "Vĩnh Long", 92.6);
            graph.AddConnection("Vĩnh Long", "Trà Vinh", 65.2);
            graph.AddConnection("Vĩnh Long", "Đồng Tháp", 50.1);
            graph.AddConnection("Vĩnh Long", "Cần Thơ", 38.8);
            graph.AddConnection("Vĩnh Long", "Hậu Giang", 81.7);
            graph.AddConnection("Đồng Tháp", "An Giang", 41.4);
            graph.AddConnection("Đồng Tháp", "Cần Thơ", 65.6);
            graph.AddConnection("An Giang", "Kiên Giang", 61.8);
            graph.AddConnection("An Giang", "Cần Thơ", 65.8);
            graph.AddConnection("Kiên Giang", "Cần Thơ", 109);
            graph.AddConnection("Kiên Giang", "Hậu Giang", 61.5);
            graph.AddConnection("Kiên Giang", "Bạc Liêu", 137);
            graph.AddConnection("Kiên Giang", "Cà Mau", 126);
            graph.AddConnection("Cần Thơ", "Hậu Giang", 48.7);
            graph.AddConnection("Hậu Giang", "Sóc Trăng", 78);
            graph.AddConnection("Hậu Giang", "Bạc Liêu", 75.5);
            graph.AddConnection("Sóc Trăng", "Bạc Liêu", 49.4);
            graph.AddConnection("Sóc Trăng", "Vĩnh Long", 93.6);
            graph.AddConnection("Sóc Trăng", "Trà Vinh", 62.9);
            graph.AddConnection("Bạc Liêu", "Cà Mau", 66.6);
            LinkedList<Car> carList = new LinkedList<Car>();
            carList.AddLast(new Car("Hino FC9JNTC", 12));
            carList.AddLast(new Car("Isuzu NQR75M", 11));
            carList.AddLast(new Car("Hyundai Mighty 110XL", 12.5));
            carList.AddLast(new Car("Fuso Canter 5.0", 10));
            carList.AddLast(new Car("Tera 350", 10));
            comboBox3.Items.Clear();
            foreach (var car in carList)
            {
                comboBox3.Items.Add(car);
            }
            comboBox3.DisplayMember = "Name";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem == null || comboBox2.SelectedItem == null)
            {
                MessageBox.Show("Vui lòng chọn điểm bắt đầu và điểm kết thúc.");
                return;
            }
            string start = comboBox1.SelectedItem.ToString();
            string end = comboBox2.SelectedItem.ToString();
            int startIndex = graph.GetLocationIndex(start);
            int endIndex = graph.GetLocationIndex(end);
            if (startIndex == -1 || endIndex == -1)
            {
                MessageBox.Show("Lỗi: Không tìm thấy vị trí trong danh sách.");
                return;
            }
            shortestPath = null;
            for (int i = 0; i < graph.nVerts; i++)
            {
                graph.vertexList[i].IsInTree = false;
                graph.vertexList[i].Distance = int.MaxValue;
                graph.vertexList[i].parent = -1;
            }
            graph.Path(startIndex);
            shortestPath = graph.GetShortestPath(startIndex, endIndex);
            double weight;
            if (double.TryParse(textBox6.Text, out weight))
            {
                if (weight <= 0)
                {
                    MessageBox.Show("Khối lượng phải lớn hơn 0!", "Lỗi nhập liệu", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                else if (weight > 5)
                {
                    MessageBox.Show("Khối lượng không được vượt quá 5 tấn!", "Lỗi nhập liệu", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                double distancecost = graph.DistanceCost(shortestPath, weight);
                textBox2.Text = distancecost.ToString("N0") + " VND";
            }
            else
            {
                MessageBox.Show("Vui lòng nhập khối lượng hợp lệ (số thực)!", "Lỗi nhập liệu", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            double totalfualcost = graph.Calculatefualcost(shortestPath);
            double totalcost = graph.Calculatefualcost(shortestPath) + graph.DistanceCost(shortestPath, weight);
            double totaldistance = graph.TotalDistance(shortestPath);
            textBox3.Text = totalcost.ToString("N0") + " VND";
            textBox4.Text = totalfualcost.ToString("N0") + " VND";
            textBox7.Text = totaldistance.ToString("N0") + " km";
            pictureBox1.Invalidate();
        }
        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            if (double.TryParse(textBox6.Text, out double weight))
            {
                Weight = weight;
            }
        }
        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Brush start = Brushes.Green;
            Brush end = Brushes.Red;
            Brush normal = Brushes.Black;
            Brush pathBrush = Brushes.Yellow;
            for (int i = 0; i < graph.nVerts; i++)
            {
                if (graph.vertexList[i] == null)
                {
                    continue;
                }
                if (shortestPath != null && shortestPath.header.flink != null)
                {
                    int startIndex = (int)shortestPath.header.flink.element;
                    Node2 current = shortestPath.header;
                    while (current.flink != null)
                    {
                        current = current.flink;
                    }
                    int endIndex = (int)current.element;
                    if (i == startIndex)
                    {
                        g.FillEllipse(start, graph.vertexList[i].X - 5, graph.vertexList[i].Y - 5, 10, 10);
                    }
                    else if (i == endIndex)
                    {
                        g.FillEllipse(end, graph.vertexList[i].X - 5, graph.vertexList[i].Y - 5, 10, 10);
                    }
                    else
                    {
                        g.FillEllipse(normal, graph.vertexList[i].X - 5, graph.vertexList[i].Y - 5, 10, 10);
                    }
                }
                else
                {

                    g.FillEllipse(normal, graph.vertexList[i].X - 5, graph.vertexList[i].Y - 5, 10, 10);

                }
            }
            for (int i = 0; i < graph.nVerts; i++)
            {
                for (int j = 0; j < graph.nVerts; j++)
                {
                    if (graph.adjMat[i, j] != graph.infinity)
                    {
                        g.DrawLine(Pens.Black, graph.vertexList[i].X, graph.vertexList[i].Y, graph.vertexList[j].X, graph.vertexList[j].Y);
                    }
                }
            }
            if (shortestPath != null)
            {
                Node2 current = shortestPath.header.flink;
                while (current != null && current.flink != null)
                {
                    int fromstart = (int)current.element;
                    int fromend = (int)current.flink.element;
                    g.DrawLine(new Pen(Color.Yellow, 3), graph.vertexList[fromstart].X, graph.vertexList[fromstart].Y, graph.vertexList[fromend].X, graph.vertexList[fromend].Y);
                    current = current.flink;

                }
            }
        }
        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox3.SelectedItem is Car car)
            {
                selectedCar = car; 
                graph.fuelEfficiency = selectedCar.FuelEfficiency;
            }
        }
    }
    public class Node
    {
        public object element;
        public Node link;
        public Node()
        {
            element = null;
            link = null;
        }
        public Node(object element)
        {
            this.element = element;
            link = null;
        }
    }
    public class LinkedList
    {
        public Node header;
        public LinkedList()
        {
            header = new Node("Header");
        }
        private Node Find(object element)
        {
            Node current = new Node();
            current = header;
            while (current.element != element)
            {
                current = current.link;
            }
            return current;
        }
        public void Insert(object newelement, object afterelement)
        {
            Node current = new Node();
            Node newnode = new Node(newelement);
            current = Find(afterelement);
            newnode.link = current.link;
            current.link = newnode;
        }
        public Node FindPrev(object element)
        {
            Node current = header;
            while (current.link != null && current.link.element != element)
            {
                current = current.link;
            }
            return current;
        }
        public void Remove(object element)
        {
            Node current = FindPrev(element);
            if (current.link != null)
            {
                current.link = current.link.link;
            }
        }
    }
    public class Node2
    {
        public object element;
        public Node2 flink, blink;
        public Node2()
        {
            element = null;
            flink = blink = null;
        }
        public Node2(object element)
        {
            this.element = element;
            flink = blink = null;
        }
    }
    public class DoubleLinkedList
    {
        public Node2 header;
        public DoubleLinkedList()
        {
            header = new Node2("Header");
        }
        private Node2 Find(object element)
        {
            Node2 current = new Node2();
            current = header;
            while (current.element != element)
            {
                current = current.flink;
            }
            return current;
        }
        public void Insert(object newelement, object afterelement)
        {
            Node2 current = new Node2();
            Node2 newnode = new Node2(newelement);
            current = Find(afterelement);
            newnode.flink = current.flink;
            newnode.blink = current;
            current.flink = newnode;
        }
        public void Remove(object element)
        {
            Node2 current = Find(element);
            if (current.flink != null)
            {
                current.blink.flink = current.flink;
                current.flink.blink = current.blink;
                current.flink = null;
                current.blink = null;
            }
        }

    }
    public class Location
    {
        public string Name { get; }
        public string Symbol { get; }
        public Point Coordinates { get; }
        public Location(string name, string symbol, int x, int y)
        {
            Name = name;
            Symbol = symbol;
            Coordinates = new Point(x, y);
        }
    }
    public class Car
    {
        public string Name { get; set; }
        public double FuelEfficiency { get; set; }
        public Car(string name, double fuelEfficiency)
        {
            Name = name;
            FuelEfficiency = fuelEfficiency;
        }
    }
    public class Vertex
    {
        public string Name { get; }
        public bool IsInTree { get; set; }
        public int parent { get; set; }
        public int Distance { get; set; }
        public int X { get; } 
        public int Y { get; } 
        public Vertex(string name,int x, int y)
        {
            Name = name;
            IsInTree = false;
            parent = -1;
            Distance = int.MaxValue;
            X = x;
            Y = y;
        }
    }
    public struct PqItem
    {
        public int Priority;
        public int Index;

        public PqItem(int index, int priority)
        {
            Index = index;
            Priority = priority;
        }
    }
    public class PQueue : Queue<PqItem>
    {
        public PQueue() : base() { }

        public new PqItem Dequeue()
        {
            PqItem[] items = this.ToArray();
            int minIndex = 0;
            int minPriority = items[0].Priority;

            for (int x = 1; x < items.Length; x++)
            {
                if (items[x].Priority < minPriority)
                {
                    minPriority = items[x].Priority;
                    minIndex = x;
                }
            }

            this.Clear();

            for (int x = 0; x < items.Length; x++)
            {
                if (x != minIndex)
                {
                    this.Enqueue(items[x]);
                }
            }

            return items[minIndex];
        }

        public void Enqueue(int index, int priority)
        {
            base.Enqueue(new PqItem(index, priority));
        }
    }
    public class Graph
    {
        private const int max_verts = 20;
        public int infinity = 1000000;
        private double fuelPricePerLitre = 20000;
        public double fuelEfficiency ;
        public double weight;
        public double costperKM = 24000;
        public double[,] totalfuelcost;
        public double[,] totalcostperKM;
        public Vertex[] vertexList;
        public double[,] adjMat;
        public int nVerts;
        private PQueue pq;
        public Graph()
        {
            vertexList = new Vertex[max_verts];
            adjMat = new double[max_verts, max_verts];
            totalfuelcost = new double[max_verts,max_verts];
            totalcostperKM = new double[max_verts, max_verts];
            nVerts = 0;
            pq = new PQueue();
            for (int j = 0; j < max_verts; j++)
            {
                for (int k = 0; k < max_verts; k++)
                {
                    adjMat[j, k] = infinity;
                    totalfuelcost[j, k]= infinity;
                    totalcostperKM[j, k] = infinity;
                }
            }
        }
        public void AddVertex(string label, int x, int y)
        {
            vertexList[nVerts++] = new Vertex(label, x, y);
        }
        public void AddEdge(int start, int end, double distance)
        {
  
            adjMat[start, end] = distance;
            adjMat[end, start] = distance;
            double cosperKM = distance * costperKM*weight;
            totalcostperKM[start, end] = (double)cosperKM;
            totalcostperKM[end, start] = (double)cosperKM;
            double fuelcost = (distance / 100)*fuelEfficiency* fuelPricePerLitre;
            totalfuelcost[start, end] = (double)fuelcost;
            totalfuelcost[end, start] = (double)fuelcost;
        }
        public double Calculatefualcost(DoubleLinkedList path)
        {
            double totalDistance = 0;
            Node2 current = path.header.flink;

            while (current != null && current.flink != null)
            {
                int start = (int)current.element;
                int end = (int)current.flink.element;

                totalDistance += adjMat[start, end];
                current = current.flink;
            }
            double fuelcost = (totalDistance / 100)* fuelEfficiency * fuelPricePerLitre;
            return fuelcost;
        }
        public double DistanceCost(DoubleLinkedList path ,double weight)
        {
            double totalDistance = 0;
            Node2 current = path.header.flink;

            while (current != null && current.flink != null)
            {
                int start = (int)current.element;
                int end = (int)current.flink.element;

                totalDistance += adjMat[start, end];
                current = current.flink;
            }
            double distancecost = totalDistance* costperKM*weight;
            return distancecost;
        }
        public double TotalDistance(DoubleLinkedList path)
        {
            double totalDistance = 0;
            Node2 current = path.header.flink;

            while (current != null && current.flink != null)
            {
                int start = (int)current.element;
                int end = (int)current.flink.element;

                totalDistance += adjMat[start, end];
                current = current.flink;
            }
            return totalDistance;
        }

        public void Path(int start)
        {
            vertexList[start].Distance = 0;
            pq.Enqueue(start, 0);
            while (pq.Count > 0)
            {
                PqItem pqItem = pq.Dequeue();
                int current = pqItem.Index;
                vertexList[current].IsInTree = true;
                for (int j = 0; j < nVerts; j++)
                {
                    if (!vertexList[j].IsInTree && adjMat[current, j] != infinity)
                    {
                       double costPerKm =totalcostperKM[current, j];
                       double fuelCost = totalfuelcost[current, j];
                       double newCost = vertexList[current].Distance + costPerKm+fuelCost;
                        if (newCost < vertexList[j].Distance)
                        {
                            vertexList[j].Distance = (int)newCost;
                            vertexList[j].parent = current;
                            pq.Enqueue(j, (int)newCost);
                        }
                    }

                }
            }
        }
        public void AddConnection(string from, string to, double distance)
        {
            int fromIndex = GetLocationIndex(from);
            int toIndex = GetLocationIndex(to);

            if (fromIndex != -1 && toIndex != -1)
            {
                AddEdge(fromIndex, toIndex, distance);
            }
        }
        public void AddLocation(string name, string symbol, int x, int y)
        {
            AddVertex(name, x, y);
        }
        public LinkedList GetLocations()
        {
            LinkedList locations = new LinkedList();
            if (nVerts == 0) return locations; 
            locations.Insert(vertexList[0].Name, "Header"); 
            for (int i = 1; i < nVerts; i++)
            {
                locations.Insert(vertexList[i].Name, vertexList[i - 1].Name);
            }
            return locations;
        }
        public int GetLocationIndex(string name)
        {
            for (int i = 0; i < nVerts; i++)
            {
                if (vertexList[i].Name == name)
                {
                    return i;
                }
            }
            return -1;
        }
        public DoubleLinkedList GetShortestPath(int start, int end)
        {
            DoubleLinkedList path = new DoubleLinkedList();
            int current = end;
            path.Insert(current, "Header");
            while (current != -1)
            {
                current = vertexList[current].parent;
                if (current != -1)
                {
                    path.Insert(current, "Header");
                }
            }
            return path;
        }

    }

}
